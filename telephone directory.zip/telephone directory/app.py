from flask import Flask,render_template,request,url_for
app = Flask(__name__)
@app.route("/")
def index():
    return render_template("index.html")
d={"Name":"PhoneNo"}
@app.route("/add",methods=['GET','POST'])
def add():
    var1 = request.form.get("key")
    var2 = request.form.get("value")
    d[var1]=var2
    return render_template("add.html",var1=var1,var2=var2,d=d)
@app.route("/display",methods=['GET','POST'])
def display():
    return render_template("display.html",d=d)
@app.route("/search",methods=['GET','POST'])
def search():
    var3 = request.form.get("searchs")
    return render_template("search.html",var3=var3,d=d)
if __name__ == "__main__":
    app.run(debug=True)
